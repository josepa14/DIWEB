$(document).ready(function(){
$("#divform").click(function(){
    $(this).find("form").slideToggle(400)
   
})
$("form").hide()



})